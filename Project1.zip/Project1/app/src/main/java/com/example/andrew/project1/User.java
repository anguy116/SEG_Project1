package com.example.andrew.project1;

import com.example.andrew.project1.HomeOwnerUser;
import com.example.andrew.project1.ServiceProviderUser;

public class User {
    HomeOwnerUser[] users = new HomeOwnerUser[50];
    ServiceProviderUser[] providers = new ServiceProviderUser[50];

}
